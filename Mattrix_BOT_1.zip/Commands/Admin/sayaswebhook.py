import discord
from discord.ext import commands
@commands.command()
async def sayaswebhook(ctx,*,args):
    
    pass
def setup(bot):
    bot.add_command(sayaswebhook)