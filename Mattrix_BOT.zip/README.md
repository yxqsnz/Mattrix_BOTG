# Mattrix BOT
## um Simples bot do discord
## Criado Pelo LickBrines(MeiaNoiite no github)
# Como usar?
## Primeiro rode o comando (Tenha certeza que o python está instalado!)
#### `pip install -r requirements.txt`
## Depois Crie um arquivo `config.env`
## as variaveis que o bot usa são
### `TOKEN` Para o Token do bot
### `PREFIX` Para o Prefixo do bot
### `REDDIT_ID` Para o Client_id do Reddit
### `REDDIT_CS` Para o Client_Secret do Reddit
### `REDDIT_UG` Para o User Agent do Reddit
## Para Rodar o bot `python main.py` no linux ou mac `python3 main.py`