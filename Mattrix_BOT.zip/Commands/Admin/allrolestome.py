from discord import Guild,Member
from discord.ext import commands
from asyncio import sleep
import discord
from discord.ext.commands.context import Context
from main import bot
@commands.command()
async def allrolestome(ctx:Context):
    sv:Guild = ctx.guild
    mem:Member = ctx.author
    rlad=0
    m = await ctx.send(rlad)
    for role in await sv.fetch_roles():
       rlad += 1
       await ctx.send(role)
       await mem.add_roles(roles=role)
       await m.edit(content=f"Cargo {rlad} de {len(sv.roles)}")
       await sleep(1)
def setup(bot):
    bot.add_command(allrolestome)